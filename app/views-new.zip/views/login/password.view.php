
<div class="align-content-center flex-wrap" style="width: 60%;margin: 200px auto;">
    <div class="container">
        <div class="login-content">
            <div class="login-form">
                <form method="post">
                    <div class="form-group">
                        <label>Email address</label>
                        <input type="email" class="form-control" placeholder="Email" name="email">
                    </div>
                    <input type="submit" class="btn btn-primary btn-flat m-b-15">

                </form>
            </div>
        </div>
    </div>
</div>
