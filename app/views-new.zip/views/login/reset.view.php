<div class="panel-login">
	<div class="panel-body">
		<form id="login-form" action="" method="post" role="form" style="display: block;">
			<div class="form-group">
				<input type="password" required name="password" id="password" tabindex="2" class="form-control" placeholder="Password">
			</div>
			<div class="form-group">
				<input type="password" required name="confirm-password" id="confirm-password" tabindex="2" class="form-control" placeholder="Confirm Password">
			</div>

			<br>
			<div class="form-group">
				<div class="row">
					<div class="col-sm-6 col-sm-offset-3">
						<input type="submit" name="submit" id="submit" tabindex="4" class="form-control btn btn-login" value="RESET PASSWORD">
					</div>
				</div>
			</div>
		</form>
	</div>
</div>
