<!-- ##### Reservation Area Start ##### -->
<section class="rooms-area section-padding-0-100">
   <div class="container">
      <div class="row justify-content-center">
          <div class="col-12 col-lg-6">
              <div class="section-heading text-center">
                  <div class="line-"></div>
                  <h2>Choose a room</h2>
              </div>
          </div>
      </div>

<script>
    jQuery(document).ready(function() {


        $('#rooms').on('change', function (event) {

        })
    });

    function CreateRoom(name, id, width) {
        let room = $('#main-rooms-select').clone();
        room[0].removeAttribute('class');
        room[0].setAttribute('class', 'col-md-'+width+' form-group');
        room[0].children[1].id = id;
        room[0].children[1].name = name;
        room.css({'display': 'block'});
        return room;
    }

    function CreateGuest(name, id, width) {
        let guestDiv = document.createElement('div');
        let guestLabel = document.createElement('label');
        let guestInput = document.createElement('input');

        guestDiv.classList = 'col-md-'+width+' form-group';
        guestLabel.innerText = 'Guest Name';
        guestInput.classList = 'form-control';
        guestInput.type = 'text';
        guestInput.name = name;
        guestInput.id = id;
        guestInput.setAttribute('required', '');

        guestDiv.append(guestLabel);
        guestDiv.append(guestInput);

        return guestDiv;
    }

    function AddAnotherRoom(e) {
        e.preventDefault();
        let rooms = document.getElementById('room-guestName-area').children.length;

        let div = document.createElement('div');
        div.className = 'row';
        div.id = 'room-area' + rooms;

        let room = CreateRoom('room' + rooms, 'room' + rooms, '6');
        let guestDiv = CreateGuest('room'+ rooms +'-guest-name', 'room'+ rooms +'-guest-name', '6');
        room.appendTo(div);
        div.append(guestDiv);

        let remove_room = "<a href='#' onclick='RemoveRoom(event); CalcTotal();' style='color: #007bff;position: absolute;right: -7%;margin-top: 25px;z-index: 100'>Remove</a>";

        $('#room-guestName-area').append(div);
        $('#room-area' + rooms).append(remove_room);
    }

    function RemoveRoom(e) {
        e.preventDefault();
        e.target.parentElement.remove();
    }

    function CheckRoomsCount() {
        let guestsEl = document.getElementById('guests');
        let guests = guestsEl.options[guestsEl.selectedIndex].value;

        if (guests > 1) {
            if (document.getElementById('room-area')) {
                document.getElementById('room-area').remove();
            }

            let rooms = "<div class='col-md-6 form-group'>" +
                "   <label for='room'>Rooms</label>" +
                "   <select onchange='ApplyRoomsCount(event); CalcTotal()' name='rooms' id='rooms' class='form-control'>";

            if (guests == 2) {
                rooms += " <option value='1'>1 Room</option>" +
                    " <option value='2'>2 Rooms</option>";
            } else if (guests == 3) {
                rooms += " <option value='2'>2 Rooms</option>" +
                    " <option value='3'>3 Rooms</option>";
            } else if (guests == 4) {
                rooms += " <option value='2'>2 Rooms</option>" +
                    " <option value='3'>3 Rooms</option>" +
                    " <option value='4'>4 Rooms</option>";
            } else {
                rooms += " <option value='3'>3 Rooms</option>" +
                    " <option value='4'>4 Rooms</option>" +
                    " <option value='5'>5 Rooms</option>";
            }

            rooms += "</select></div>";
            document.getElementById('rooms-count-container').innerHTML = rooms;
            $('#rooms').change();
        } else {
            document.getElementById('rooms-count-container').innerHTML = ' ';
            document.getElementById('room-guestName-area').innerHTML = ' ';

            let div = document.createElement('div');
            div.className = 'row';
            div.id = 'room-area';

            let room = CreateRoom('room', 'room', '6');
            let guestDiv = CreateGuest('room-guest-name', 'room-guest-name', '6');

            room.appendTo(div);
            div.append(guestDiv);

            $('#room-guestName-area').append(div);
        }
    }

    function ApplyRoomsCount(event) {
        let rooms = event.target.selectedOptions[0].value;
        let guestsEl = document.getElementById('guests');
        let guests = guestsEl.options[guestsEl.selectedIndex].value;

        $('#room-guestName-area').html(' ');

        if (guests == 2) {
            if (rooms == 1) {
                let div = document.createElement('div');
                div.className = 'row';
                div.id = 'room-area0';

                let room = CreateRoom('room0', 'room0', '4');
                let guestDiv = CreateGuest('room0-guest-name', 'room0-guest-name', '4');
                let guestDiv0 = CreateGuest('room0-guest-name0', 'room0-guest-name0', '4');

                room.appendTo(div);
                div.append(guestDiv);
                div.append(guestDiv0);

                $('#room-guestName-area').append(div);
            } else if (rooms == 2) {
                for (let i = 0; i < 2; i++) {
                    let div = document.createElement('div');
                    div.className = 'row';
                    div.id = 'room-area' + i;

                    let room = CreateRoom('room' + i, 'room' + i, '6');
                    let guestDiv = CreateGuest('room'+ i +'-guest-name', 'room'+ i +'-guest-name', '6');
                    room.appendTo(div);
                    div.append(guestDiv);

                    $('#room-guestName-area').append(div);
                }
            }
        } else if (guests == 3) {
            if (rooms == 2) {
                let div = document.createElement('div');
                div.className = 'row';
                div.id = 'room-area0';

                let div0 = document.createElement('div');
                div0.className = 'row';
                div0.id = 'room-area1';

                let room = CreateRoom('room0', 'room0', '6');
                let guestDiv = CreateGuest('room0-guest-name', 'room0-guest-name', '6');
                room.appendTo(div);
                div.append(guestDiv);

                let room0 = CreateRoom('room1', 'room1', '4');
                let guestDiv0 = CreateGuest('room1-guest-name', 'room1-guest-name', '4');
                let guestDiv1 = CreateGuest('room1-guest-name0', 'room1-guest-name0', '4');

                room0.appendTo(div0);
                div0.append(guestDiv0);
                div0.append(guestDiv1);

                $('#room-guestName-area').append(div, div0);
            } else if (rooms == 3) {
                for (let i = 0; i < 3; i++) {
                    let div = document.createElement('div');
                    div.className = 'row';
                    div.id = 'room-area' + i;

                    let room = CreateRoom('room' + i, 'room' + i, '6');
                    let guestDiv = CreateGuest('room'+ i +'-guest-name', 'room'+ i +'-guest-name', '6');
                    room.appendTo(div);
                    div.append(guestDiv);

                    $('#room-guestName-area').append(div);
                }
            }
        } else if (guests == 4) {
            if (rooms == 2) {
                let div = document.createElement('div');
                div.className = 'row';
                div.id = 'room-area0';

                let div0 = document.createElement('div');
                div0.className = 'row';
                div0.id = 'room-area1';

                let room = CreateRoom('room0', 'room0', '4');
                let guestDiv = CreateGuest('room0-guest-name', 'room0-guest-name', '4');
                let guestDiv0 = CreateGuest('room0-guest-name0', 'room0-guest-name0', '4');
                room.appendTo(div);
                div.append(guestDiv);
                div.append(guestDiv0);

                let room0 = CreateRoom('room1', 'room1', '4');
                let guestDiv1 = CreateGuest('room1-guest-name', 'room1-guest-name', '4');
                let guestDiv2 = CreateGuest('room1-guest-name0', 'room1-guest-name0', '4');

                room0.appendTo(div0);
                div0.append(guestDiv1);
                div0.append(guestDiv2);

                $('#room-guestName-area').append(div, div0);
            } else if (rooms == 3) {
                let div0 = document.createElement('div');
                div0.className = 'row';
                div0.id = 'room-area0';

                let div1 = document.createElement('div');
                div1.className = 'row';
                div1.id = 'room-area1';

                let div2 = document.createElement('div');
                div2.className = 'row';
                div2.id = 'room-area2';

                let room0 = CreateRoom('room0', 'room0', '4');
                let guestDiv = CreateGuest('room0-guest-name', 'room0-guest-name', '4');
                let guestDiv0 = CreateGuest('room0-guest-name0', 'room0-guest-name0', '4');
                room0.appendTo(div0);
                div0.append(guestDiv);
                div0.append(guestDiv0);

                let room1 = CreateRoom('room1', 'room1', '6');
                let guestDiv1 = CreateGuest('room1-guest-name', 'room1-guest-name', '6');
                room1.appendTo(div1);
                div1.append(guestDiv1);

                let room2 = CreateRoom('room2', 'room2', '6');
                let guestDiv2 = CreateGuest('room2-guest-name', 'room2-guest-name', '6');
                room2.appendTo(div2);
                div2.append(guestDiv2);

                $('#room-guestName-area').append(div0, div1, div2);
            } else if (rooms == 4) {
                for (let i = 0; i < 4; i++) {
                    let div = document.createElement('div');
                    div.className = 'row';
                    div.id = 'room-area' + i;

                    let room = CreateRoom('room' + i, 'room' + i, '6');
                    let guestDiv = CreateGuest('room'+ i +'-guest-name', 'room'+ i +'-guest-name', '6');
                    room.appendTo(div);
                    div.append(guestDiv);

                    $('#room-guestName-area').append(div);
                }
            }
        } else {
            if (rooms == 3) {
                let div0 = document.createElement('div');
                div0.className = 'row';
                div0.id = 'room-area0';

                let div1 = document.createElement('div');
                div1.className = 'row';
                div1.id = 'room-area1';

                let div2 = document.createElement('div');
                div2.className = 'row';
                div2.id = 'room-area2';

                let room0 = CreateRoom('room0', 'room0', '4');
                let guestDiv = CreateGuest('room0-guest-name', 'room0-guest-name', '4');
                let guestDiv0 = CreateGuest('room0-guest-name0', 'room0-guest-name0', '4');
                room0.appendTo(div0);
                div0.append(guestDiv);
                div0.append(guestDiv0);

                let room1 = CreateRoom('room1', 'room1', '4');
                let guestDiv1 = CreateGuest('room1-guest-name', 'room1-guest-name', '4');
                let guestDiv3 = CreateGuest('room1-guest-name0', 'room1-guest-name0', '4');
                room1.appendTo(div1);
                div1.append(guestDiv1);
                div1.append(guestDiv3);

                let room2 = CreateRoom('room2', 'room2', '6');
                let guestDiv2 = CreateGuest('room2-guest-name', 'room2-guest-name', '6');
                room2.appendTo(div2);
                div2.append(guestDiv2);

                $('#room-guestName-area').append(div0, div1, div2);
            } else if (rooms == 4) {
                let div0 = document.createElement('div');
                div0.className = 'row';
                div0.id = 'room-area0';

                let room0 = CreateRoom('room0', 'room0', '4');
                let guestDiv = CreateGuest('room0-guest-name', 'room0-guest-name', '4');
                let guestDiv0 = CreateGuest('room0-guest-name0', 'room0-guest-name0', '4');
                room0.appendTo(div0);
                div0.append(guestDiv);
                div0.append(guestDiv0);

                $('#room-guestName-area').append(div0);

                for (let i = 1; i < 4; i++) {
                    let div = document.createElement('div');
                    div.className = 'row';
                    div.id = 'room-area' + i;

                    let room = CreateRoom('room' + i, 'room' + i, '6');
                    let guestDiv = CreateGuest('room'+ i +'-guest-name', 'room'+ i +'-guest-name', '6');
                    room.appendTo(div);
                    div.append(guestDiv);

                    $('#room-guestName-area').append(div);
                }
            } else if (rooms == 5) {
                for (let i = 0; i < 5; i++) {
                    let div = document.createElement('div');
                    div.className = 'row';
                    div.id = 'room-area' + i;

                    let room = CreateRoom('room' + i, 'room' + i, '6');
                    let guestDiv = CreateGuest('room'+ i +'-guest-name', 'room'+ i +'-guest-name', '6');
                    room.appendTo(div);
                    div.append(guestDiv);

                    $('#room-guestName-area').append(div);
                }
            }

            let add_room = "<a href='#' onclick='AddAnotherRoom(event); CalcTotal();' style='color: #007bff'>Add Room</a>";
            $('#add-room-button-area').html(add_room);
        }

        // for (let i = 0; i < guests - 1; i++) {
        //     let div = document.createElement('div');
        //     let div0 = document.createElement('div');
        //     let label = document.createElement('label');
        //
        //     let guestDiv = document.createElement('div');
        //     let guestLabel = document.createElement('label');
        //     let guestInput = document.createElement('input');
        //
        //     div.className = 'row';
        //     div.id = 'room-area' + i;
        //     div0.classList = 'col-md-6 form-group';
        //     label.innerText = 'Room';
        //
        //     guestDiv.classList = 'col-md-6 form-group';
        //     guestLabel.innerText = 'Guest Name';
        //     guestInput.classList = 'form-control';
        //     guestInput.type = 'text';
        //     guestInput.name = 'guest-name' + i;
        //     guestInput.id = 'guest-name' + i;
        //     guestInput.setAttribute('required', '');
        //
        //
        //     let room = $('#room').clone();
        //     room[0].id = 'room' + i;
        //     room[0].name = 'room_id' + i;
        //     room.css({'display': 'block'});
        //
        //     div0.append(label);
        //     room.appendTo(div0);
        //
        //     guestDiv.append(guestLabel);
        //     guestDiv.append(guestInput);
        //
        //     div.append(div0);
        //     div.append(guestDiv);
        //
        //     $('#room-guestName-area').append(div);
        // }
    }

    function CheckGuestName(e) {
        let type = e.target.selectedOptions[0].attributes.type.value;
        let roomArea = e.target.parentElement.parentElement;
        let guestName = roomArea.children[1];

        // if (type = 'double') {
        //     guestName.remove();
        //
        //     let guestDiv = document.createElement('div');
        //     let guestLabel = document.createElement('label');
        //     let guestInput = document.createElement('input');
        //
        //     guestDiv.classList = 'col-md-3 form-group';
        //     guestLabel.innerText = 'Guest Name';
        //     guestInput.classList = 'form-control';
        //     guestInput.type = 'text';
        //     guestInput.name = 'guest-name' + i;
        //     guestInput.id = 'guest-name' + i;
        //     guestInput.setAttribute('required', '');
        // }
        
    }
</script>

      <div class="row">
         <div class="col-md-6">

             <div class="col-md-6 form-group" style="margin-bottom: -10px;display: none" id="main-rooms-select">
                 <label for="room">Room</label>
                 <?php if (isset($rooms) && $rooms != false) : ?>
                     <select name="room" id="room" class="form-control" required onchange="CheckGuestName(event); ChangeFeaturedRoom(event); CalcTotal()">
                         <?php foreach ($rooms as $room) : ?>
                             <option value="<?= $room->room_id ?>" type="<?= $room->room_type ?>"><?= 'Room #' . $room->room_number . ' - ' . ucfirst($room->room_type) ?></option>
                         <?php endforeach; ?>
                     </select>
                 <?php endif; ?>
             </div>

            <form action="" method="post">

              <?php if (isset($_COOKIE['reservation-values']) && !empty($_COOKIE['reservation-values'])) : ?>
                <?php if (json_decode($_COOKIE['reservation-values'])[0] == '1') : ?>
                  <?php if (isset(json_decode($_COOKIE['reservation-values'])[2]) && isset(json_decode($_COOKIE['reservation-values'])[3])) : ?>
                    <script>
                      $( document ).ready(function() {
                        $('#arrival_date').datepicker({dateFormat: "dd/mm/yy" }).val(new Date("<?= json_decode($_COOKIE['reservation-values'])[2] ?>, " + new Date().getFullYear()).toDateString()).trigger('change');
                        $('#departure_date').datepicker({dateFormat: "dd/mm/yy" }).val(new Date("<?= json_decode($_COOKIE['reservation-values'])[3] ?>, " + new Date().getFullYear()).toDateString()).trigger('change');
                      });
                    </script>
                  <?php endif; ?>
                <?php endif; ?>
              <?php endif; ?>

               <div class="row">
                  <div class="col-sm-6 form-group">
                     <label for="">Arrival Date</label>
                     <div style="position: relative;">
                        <input onchange="CalcTotal()" type='text' placeholder="dd/mm/yyyy" name="check_in" class="form-control reservation_date" id='arrival_date' required autocomplete="off" />
                     </div>
                  </div>

                  <div class="col-sm-6 form-group">
                     <label for="">Departure Date</label>
                     <div style="position: relative;">
                        <input onchange="CalcTotal()" type='text' placeholder="dd/mm/yyyy" name="check_out" class="form-control reservation_date" id='departure_date' required autocomplete="off" />
                     </div>
                  </div>
               </div>


               <div class="row">
                   <?php $guests1=''; $guests2=''; $guests3=''; $guests4=''; $guests5='';  ?>
                   <?php if (isset($_COOKIE['reservation-values']) && !empty($_COOKIE['reservation-values'])) : ?>
                       <?php if (json_decode($_COOKIE['reservation-values'])[0] == '1') : ?>
                           <?php if (isset(json_decode($_COOKIE['reservation-values'])[4])) : ?>
                               <?php
                               if (json_decode($_COOKIE['reservation-values'])[4] == 1) {
                                   $guests1 = 'selected';
                               } elseif (json_decode($_COOKIE['reservation-values'])[4] == 2) {
                                   $guests2 = 'selected';
                               } elseif (json_decode($_COOKIE['reservation-values'])[4] == 3) {
                                   $guests3 = 'selected';
                               } elseif (json_decode($_COOKIE['reservation-values'])[4] == 4) {
                                   $guests4 = 'selected';
                               } elseif (json_decode($_COOKIE['reservation-values'])[4] == 5) {
                                   $guests5 = 'selected';
                               }
                               ?>
                           <?php endif; ?>
                       <?php endif; ?>
                   <?php endif; ?>
                   <div class="col-md-12 form-group" style="margin-bottom: 0">
                       <label for="guests">Guests</label>
                       <select name="guests" onchange="CheckRoomsCount(); CalcTotal()" id="guests" class="form-control" required>
                           <option <?= $guests1 ?> value="1">1 Guest</option>
                           <option <?= $guests2 ?> value="2">2 Guests</option>
                           <option <?= $guests3 ?> value="3">3 Guests</option>
                           <option <?= $guests4 ?> value="4">4 Guests</option>
                           <option <?= $guests5 ?> value="5">5+ Guests</option>
                       </select>
                   </div>
               </div>

               <div class="row" id="rooms-count-container"></div>

               <div class="row" id="room-area">
                   <div class="col-md-6 form-group" id="rooms-select-div" style="margin-bottom: -10px">
                        <label for="room0">Room</label>
                        <?php if (isset($rooms) && $rooms != false) : ?>
                            <select name="room0" id="room0" class="form-control" required onchange="CheckGuestName(event); ChangeFeaturedRoom(event); CalcTotal()">
                                <?php foreach ($rooms as $room) : ?>

                                    <?php if (isset($_COOKIE['reservation-values']) && !empty($_COOKIE['reservation-values'])) : ?>

                                        <?php if (isset(json_decode($_COOKIE['reservation-values'])[1])) : ?>

                                            <?php if (json_decode($_COOKIE['reservation-values'])[1] == $room->room_id) : ?>
                                                <option selected value="<?= $room->room_id ?>" type="<?= $room->room_type ?>"><?= 'Room #' . $room->room_number . ' - ' . ucfirst($room->room_type) ?></option>
                                            <?php else : ?>
                                                <option value="<?= $room->room_id ?>" type="<?= $room->room_type ?>"><?= 'Room #' . $room->room_number . ' - ' . ucfirst($room->room_type) ?></option>
                                            <?php endif; ?>

                                        <?php else : ?>
                                            <option value="<?= $room->room_id ?>" type="<?= $room->room_type ?>"><?= 'Room #' . $room->room_number . ' - ' . ucfirst($room->room_type) ?></option>
                                        <?php endif; ?>

                                    <?php else : ?>
                                        <option value="<?= $room->room_id ?>" type="<?= $room->room_type ?>"><?= 'Room #' . $room->room_number . ' - ' . ucfirst($room->room_type) ?></option>
                                    <?php endif; ?>

                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                    </div>

                   <div class="col-md-6 form-group" id="guest-name-div">
                       <label for="room-guest-name">Guest Name</label>
                       <input type="text" name="room-guest-name" id="room-guest-name" class="form-control" required>
                   </div>
               </div>

               <div id="room-guestName-area" style="margin-bottom: 10px;"></div>
               <div id="add-room-button-area" style="margin-bottom: 25px;"></div>

               <div class="row">
                  <div class="col-md-6 form-group">
                     <label for="">Total: </label>
                     <div style="position: relative;">
                        <input type='text' disabled name="total" class="form-control" id='total' />
                     </div>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12 form-group">
                     <label for="email">Email</label>
                     <input type="email" name="email" id="email" class="form-control " required>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-12 form-group">
                     <label for="message">Write a Note</label>
                     <textarea name="note" id="message" class="form-control " cols="30" rows="8"></textarea>
                  </div>
               </div>
               <div class="row">
                  <div class="col-md-6 form-group">
                     <input type="submit" name="submit" value="Reserve Now" class="btn btn-primary" onclick="Cookies.remove('reservation-values');">
                  </div>
               </div>
            </form>
         </div>
         
         <div class="col-md-1"></div>

         <div class="col-md-5">
            <h3 class="mb-5">Featured Room</h3>
            <div class="media d-block room mb-0">
               
               <div class="row">
                   <div class="col-12 col-md-10 col-lg-10">
                       <div class="single-rooms-area wow fadeInUp" data-wow-delay="100ms">
                           <!-- Thumbnail -->
                           <div class="bg-thumbnail bg-img" id="featured-room-background-image" style=""></div>
                           <!-- Price -->
                           <p class="price-from" style="width: 70%" id="featured-room-price"></p>
                           <!-- Rooms Text -->
                           <div class="rooms-text">
                               <div class="line"></div>
                               <h4 id="featured-room-type"></h4>
                               <h4 id="featured-room-beds"></h4>
                               <p id="featured-room-description"></p>
                           </div>
                       </div>
                   </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- END section -->
<script>
   $( document ).ready(function() {
       $('#room0').change();
       CalcTotal();
   });
</script>