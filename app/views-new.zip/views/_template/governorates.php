<?php

$gov = array(
		'Alexandria',
		'Aswan',
		'Asyut',
		'Beheira',
		'Beni Suef',
		'Cairo',
		'Dakahlia',
		'Damietta',
		'Faiyum',
		'Gharbia',
		'Giza',
		'Ismailia',
		'Kafr El Sheikh',
		'Luxor',
		'Matruh',
		'Minya',
		'Monufia',
		'New Valley',
		'North Sinai',
		'Port Said',
		'Qalyubia',
		'Qena',
		'Red Sea',
		'Sharqia',
		'Sohag',
		'South Sinai',
		'Suez'
	);


?>